from itertools import permutations

print([tuple([5,4,3,1,2,1])])

[[1,2,3,4],[1,2,3,4,4],[1,2,3,4]]